//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (c) 2002 GarageGames.Com
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Game specific profiles are located here
//-----------------------------------------------------------------------------

singleton GuiControlProfile (InvList)
{
   opaque = true;
   fontType       = "Arial";
   fontSize       = 16;
   fillColor = "150 150 158"; //selection color
   fontColor = "255 255 255";
   justify = "left";
};
   
singleton GuiControlProfile (InvScroll)
{
   //Use fillColor background
   opaque = false; 
};

singleton GuiControlProfile (InvGui)
{
   //Use fillColor background
   opaque = false;
     
   //Font
   fontType       = "Arial";
   fontSize       = 18;
   
   //Set font color - R G B (range 0 -255 )
   fontColor      = "200 200 200";
   justify        = "center";

   //Draw a border
   border         = 1;
   border         = false;    
};
