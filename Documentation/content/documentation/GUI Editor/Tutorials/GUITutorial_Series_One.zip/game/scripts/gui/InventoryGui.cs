//
//global arrays for initial content to be displayed
//

$FOOD      = 0;
$SPELLS    = 1;
$WEAPON  = 2;
$ARMOUR  = 3;

$aInv[$FOOD,0] = "Bread x 1"; 
$aInv[$FOOD,1] = "Apple x 1 "; 
$aInv[$FOOD,2] = "Pie x 2"; 

$aInv[$SPELLS,0] = "Fall From Grace";
$aInv[$SPELLS,1] = "Ice Call";
$aInv[$SPELLS,2] = "Water Wish";
$aInv[$SPELLS,3] = "Fire Storm";
$aInv[$SPELLS,4] = "Healing Heart";

$aInv[$WEAPON,0] = "Sword of Truth";
$aInv[$WEAPON,1] = "Chain Axe";
$aInv[$WEAPON,2] = "Dagger";
$aInv[$WEAPON,3] = "Elf Staff";
$aInv[$WEAPON,4] = "Ork Hammer";

$aInv[$ARMOUR,0] = "Light Mail";
$aInv[$ARMOUR,1] = "Light Sheild";
$aInv[$ARMOUR,2] = "Cursed Gloves";
$aInv[$ARMOUR,3] = "Invisiblity Cloak";

//
//Give each of our buttons a function to call
//

function inventoryGui::btn1()
{
   //set the title text 
   lblInvTitle.setValue("FOOD");
   
   //clear the list box of previous content
   lstInventory.clearItems();

   //iterate through our array adding items to our list
   for(%i = 0; %i < 4; %i++)
   { 
      lstInventory.addItem( $aInv[ $FOOD, %i ]);
   }   
}

function inventoryGui::btn2()
{
   lblInvTitle.setValue("SPELLS");
   lstInventory.clearItems();
   for(%i = 0; %i < 5; %i++)
   { 
      lstInventory.addItem( $aInv[ $SPELLS, %i ]);
   }   
}

function inventoryGui::btn3()
{
   lblInvTitle.setValue("WEAPONS");
   lstInventory.clearItems();
   for(%i = 0; %i < 5; %i++)
   { 
      lstInventory.addItem( $aInv[ $WEAPON, %i ]);
   }   
}

function inventoryGui::btn4()
{
   lblInvTitle.setValue("ARMOUR");
   lstInventory.clearItems();
   for(%i = 0; %i < 4; %i++)
   { 
      lstInventory.addItem( $aInv[ $ARMOUR, %i ]);
   }   
}
