//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// PlayGui is the main TSControl through which the game is viewed.
// The PlayGui also contains the hud controls.
//-----------------------------------------------------------------------------

function PlayGui::onWake(%this)
{
   // Turn off any shell sounds...
   // sfxStop( ... );

   $enableDirectInput = "1";
   activateDirectInput();

   // just update the action map here
   moveMap.push();

   // hack city - these controls are floating around and need to be clamped
   schedule(0, 0, "refreshCenterTextCtrl");
   schedule(0, 0, "refreshBottomTextCtrl");
   
   schedule(100,0, updateDisplay);
}

function PlayGui::onSleep(%this)
{
   // pop the keymaps
   moveMap.pop();
}

function PlayGui::clearHud( %this )
{
   while ( %this.getCount() > 0 )
      %this.getObject( 0 ).delete();
}

//-----------------------------------------------------------------------------

function refreshBottomTextCtrl()
{
   BottomPrintText.position = "0 0";
}

function refreshCenterTextCtrl()
{
   CenterPrintText.position = "0 0";
}

function updateDisplay()
{
   lblTime.setValue((getRealTime()));
   lblFps.setValue($fps::real);
   lblPoly.setValue($GFXDeviceStatistics::polyCount);
   schedule(100,0, updateDisplay);
}