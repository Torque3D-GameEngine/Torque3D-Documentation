function testList::addItem()
{
   lstTestList.addItem(txtEnter.getValue());
}

//Insert An Item at the selection
function testList::insertItem()
{
   lstTestList.insertItem(txtEnter.getValue(),lstTestList.getSelectedItem());
}

//Remove a selected Item  
function testList::removeItem()
{
   lstTestList.deleteItem(lstTestList.getSelectedItem());
}

//Fill list with content
function testList::populate()
{
   for(%i = 0; %i < 10; %i++)
   { 
      lstTestList.addItem( "Option " @ %i);
   }
}

//show selected content
function testList::getSelectedContent()
{
   %item = lstTestList.getSelectedItem();
   lblItemSelected.setValue( %item );
   lblItemText.setValue(lstTestList.getItemText( %item ));
}

//Clear the list of items
function testList::clearList()
{
   lstTestList.clearItems();
}

//Display multiselected items
function testList::multiSelect()
{
   //number of selected items
   %count = lstTestList.getSelCount();
   
   //returns a space delimited list of all the selected items indexes in the list
	%options = lstTestList.getSelectedItems();
	
   // parse selected items list
   for(%item = 0; %item < %count; %item++) 
   {
      %option = getWord(%options, %item);
      %t =  lstTestList.getItemText(%option);
      %text = %text @ %t @ "\n";
      lblMLSelected.setValue(%text );
   }
}
