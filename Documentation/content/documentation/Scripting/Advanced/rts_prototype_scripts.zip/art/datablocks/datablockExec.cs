//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// Load up all datablocks.  This function is called when
// a server is constructed.

// Do the sounds first -- later scripts/datablocks may need them
exec("./audioProfiles.cs");

// Do the various effects next -- later scripts/datablocks may need them
exec("./particles.cs");

exec("./environment.cs");
exec("./triggers.cs");
exec("./lights.cs");

// Add a rigid example
exec("./rigidShape.cs");

exec("./health.cs");

// Load our supporting weapon datablocks
exec("./weapon.cs");

// Load the weapon datablocks
exec("./weapons/rocketLauncher.cs");

// Load the default player datablocks
exec("./player.cs");

// RTS PROTOTYPE CHANGES //
exec("./BoomBot.cs");
// RTS PROTOTYPE CHANGES //

// Load our other player datablocks
exec("./aiPlayer.cs");

// Load the vehicle datablocks
exec("./vehicles/defaultCar.cs");
