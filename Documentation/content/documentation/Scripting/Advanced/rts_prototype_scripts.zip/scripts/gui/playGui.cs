//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// PlayGui is the main TSControl through which the game is viewed.
// The PlayGui also contains the hud controls.
//-----------------------------------------------------------------------------

function PlayGui::onWake(%this)
{
   // Turn off any shell sounds...
   // sfxStop( ... );

   $enableDirectInput = "1";
   activateDirectInput();

   // Message hud dialog
   Canvas.pushDialog( MainChatHud );
   chatHud.attach(HudMessageVector);

   // just update the action map here
   moveMap.push();

   // hack city - these controls are floating around and need to be clamped
   schedule(0, 0, "refreshCenterTextCtrl");
   schedule(0, 0, "refreshBottomTextCtrl");
}

function PlayGui::onSleep(%this)
{
   Canvas.popDialog( MainChatHud  );

   // pop the keymaps
   moveMap.pop();
}

function PlayGui::clearHud( %this )
{
   Canvas.popDialog( MainChatHud );

   while ( %this.getCount() > 0 )
      %this.getObject( 0 ).delete();
}

//-----------------------------------------------------------------------------

function refreshBottomTextCtrl()
{
   BottomPrintText.position = "0 0";
}

function refreshCenterTextCtrl()
{
   CenterPrintText.position = "0 0";
}

// onRightMouseDown is called when the right mouse button is clicked in the scene
// %pos is the screen (pixel) coordinates of the mouse click
// %start is the world coordinates of the camera
// %ray is a vector through the viewing 
// frustum corresponding to the clicked pixel
function PlayGui::onRightMouseDown(%this, %pos, %start, %ray)
{
   // find end of search vector
   %ray = VectorScale(%ray, 2000);
   %end = VectorAdd(%start, %ray);
   
   // only care about terrain objects
   %searchMasks = $TypeMasks::TerrainObjectType;

   // search!
   %scanTarg = ContainerRayCast( %start, %end, %searchMasks );
   
   // If the terrain object was found in the scan
   if( %scanTarg )
   {
      // Get access to the AI player we control
      %ai = LocalClientConnection.player;
            
      // Get the X,Y,Z position of where we clicked
      %pos = getWords(%scanTarg, 1, 3);
            
      // Get the normal of the location we clicked on
      %norm = getWords(%scanTarg, 4, 6);
            
      // Set the destination for the AI player to
      // make him move
      %ai.setMoveDestination( %pos );

      // If the AI player already has a decal (0 or greater)
      // tell the decal manager to delete the instance of the gg_decal
      if( %ai.decal > -1 )
         decalManagerRemoveDecal( %ai.decal );

      // Create a new decal using the decal manager
      // arguments are (Position, Normal, Rotation, Scale, Datablock, Permanent)
      // AddDecal will return an ID of the new decal, which we will
      // store in the player
      %ai.decal = decalManagerAddDecal( %pos, %norm, 0, 1, "gg_decal", true );

   }

}

// onMouseDown is called when the left mouse
// button is clicked in the scene
// %pos is the screen (pixel) coordinates of the mouse click
// %start is the world coordinates of the camera
// %ray is a vector through the viewing 
// frustum corresponding to the clicked pixel
function PlayGui::onMouseDown(%this, %pos, %start, %ray)
{   
   %ray = VectorScale(%ray, 1000);
   %end = VectorAdd(%start, %ray);

   // Only care about players this time
   %searchMasks = $TypeMasks::PlayerObjectType;

   // Search!
   %scanTarg = ContainerRayCast( %start, %end, %searchMasks );

   // Get our player/actor
   %ai = LocalClientConnection.player;
   
   // If an enemy AI object was found in the scan
   if( %scanTarg )
   {
      // Get the enemy ID
      %target = firstWord(%scanTarg);

      // Don't shoot at yourself
      if( %target != %ai )
      {
         // Cause our AI object to aim at the target
         // offset (0, 0, 1) so you don't aim at the target's feet
         %ai.setAimObject(%target, "0 0 1");
         
         // Tell our AI object to fire its weapon
         %ai.schedule(100, "setImageTrigger", 0, 1);
         %ai.schedule(150, "setImageTrigger", 0, 0);
         return;
      }
   }

   // If no valid target was found, or left mouse
   // clicked again on terrain, stop firing and aiming
   %ai.setAimObject(0);
   %ai.setImageTrigger(0, 0);
}